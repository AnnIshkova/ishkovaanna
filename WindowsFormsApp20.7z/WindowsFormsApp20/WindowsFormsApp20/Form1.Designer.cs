﻿namespace WindowsFormsApp20
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button1_2 = new System.Windows.Forms.Button();
            this.button1_1 = new System.Windows.Forms.Button();
            this.button1_3 = new System.Windows.Forms.Button();
            this.button1_4 = new System.Windows.Forms.Button();
            this.button1_5 = new System.Windows.Forms.Button();
            this.button2_1 = new System.Windows.Forms.Button();
            this.button2_2 = new System.Windows.Forms.Button();
            this.button2_3 = new System.Windows.Forms.Button();
            this.button2_4 = new System.Windows.Forms.Button();
            this.button2_5 = new System.Windows.Forms.Button();
            this.button3_1 = new System.Windows.Forms.Button();
            this.button3_2 = new System.Windows.Forms.Button();
            this.button3_3 = new System.Windows.Forms.Button();
            this.button3_4 = new System.Windows.Forms.Button();
            this.button3_5 = new System.Windows.Forms.Button();
            this.button4_1 = new System.Windows.Forms.Button();
            this.button4_2 = new System.Windows.Forms.Button();
            this.button4_3 = new System.Windows.Forms.Button();
            this.button4_4 = new System.Windows.Forms.Button();
            this.button4_5 = new System.Windows.Forms.Button();
            this.button5_1 = new System.Windows.Forms.Button();
            this.button5_2 = new System.Windows.Forms.Button();
            this.button5_3 = new System.Windows.Forms.Button();
            this.button5_4 = new System.Windows.Forms.Button();
            this.button5_5 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(480, 110);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(146, 147);
            this.textBox1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.button1_2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1_1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1_3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1_4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1_5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.button2_1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button2_2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button2_3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button2_4, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.button2_5, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.button3_1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button3_2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button3_3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button3_4, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.button3_5, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.button4_1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button4_2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.button4_3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.button4_4, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.button4_5, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.button5_1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.button5_2, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.button5_3, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.button5_4, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.button5_5, 4, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(34, 110);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(364, 297);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // button1_2
            // 
            this.button1_2.Location = new System.Drawing.Point(75, 3);
            this.button1_2.Name = "button1_2";
            this.button1_2.Size = new System.Drawing.Size(66, 53);
            this.button1_2.TabIndex = 3;
            this.button1_2.UseVisualStyleBackColor = true;
            this.button1_2.Click += new System.EventHandler(this.button1_2_Click);
            // 
            // button1_1
            // 
            this.button1_1.Location = new System.Drawing.Point(3, 3);
            this.button1_1.Name = "button1_1";
            this.button1_1.Size = new System.Drawing.Size(66, 53);
            this.button1_1.TabIndex = 3;
            this.button1_1.UseVisualStyleBackColor = true;
            this.button1_1.Click += new System.EventHandler(this.button1_1_Click);
            // 
            // button1_3
            // 
            this.button1_3.Location = new System.Drawing.Point(147, 3);
            this.button1_3.Name = "button1_3";
            this.button1_3.Size = new System.Drawing.Size(66, 53);
            this.button1_3.TabIndex = 4;
            this.button1_3.UseVisualStyleBackColor = true;
            this.button1_3.Click += new System.EventHandler(this.button1_3_Click);
            // 
            // button1_4
            // 
            this.button1_4.Location = new System.Drawing.Point(219, 3);
            this.button1_4.Name = "button1_4";
            this.button1_4.Size = new System.Drawing.Size(66, 53);
            this.button1_4.TabIndex = 5;
            this.button1_4.UseVisualStyleBackColor = true;
            this.button1_4.Click += new System.EventHandler(this.button1_4_Click);
            // 
            // button1_5
            // 
            this.button1_5.Location = new System.Drawing.Point(291, 3);
            this.button1_5.Name = "button1_5";
            this.button1_5.Size = new System.Drawing.Size(70, 53);
            this.button1_5.TabIndex = 6;
            this.button1_5.UseVisualStyleBackColor = true;
            this.button1_5.Click += new System.EventHandler(this.button1_5_Click);
            // 
            // button2_1
            // 
            this.button2_1.Location = new System.Drawing.Point(3, 62);
            this.button2_1.Name = "button2_1";
            this.button2_1.Size = new System.Drawing.Size(66, 53);
            this.button2_1.TabIndex = 7;
            this.button2_1.UseVisualStyleBackColor = true;
            this.button2_1.Click += new System.EventHandler(this.button2_1_Click);
            // 
            // button2_2
            // 
            this.button2_2.Location = new System.Drawing.Point(75, 62);
            this.button2_2.Name = "button2_2";
            this.button2_2.Size = new System.Drawing.Size(66, 53);
            this.button2_2.TabIndex = 8;
            this.button2_2.UseVisualStyleBackColor = true;
            this.button2_2.Click += new System.EventHandler(this.button2_2_Click);
            // 
            // button2_3
            // 
            this.button2_3.Location = new System.Drawing.Point(147, 62);
            this.button2_3.Name = "button2_3";
            this.button2_3.Size = new System.Drawing.Size(66, 53);
            this.button2_3.TabIndex = 9;
            this.button2_3.UseVisualStyleBackColor = true;
            this.button2_3.Click += new System.EventHandler(this.button2_3_Click);
            // 
            // button2_4
            // 
            this.button2_4.Location = new System.Drawing.Point(219, 62);
            this.button2_4.Name = "button2_4";
            this.button2_4.Size = new System.Drawing.Size(66, 53);
            this.button2_4.TabIndex = 10;
            this.button2_4.UseVisualStyleBackColor = true;
            this.button2_4.Click += new System.EventHandler(this.button2_4_Click);
            // 
            // button2_5
            // 
            this.button2_5.Location = new System.Drawing.Point(291, 62);
            this.button2_5.Name = "button2_5";
            this.button2_5.Size = new System.Drawing.Size(70, 53);
            this.button2_5.TabIndex = 11;
            this.button2_5.UseVisualStyleBackColor = true;
            this.button2_5.Click += new System.EventHandler(this.button2_5_Click);
            // 
            // button3_1
            // 
            this.button3_1.Location = new System.Drawing.Point(3, 121);
            this.button3_1.Name = "button3_1";
            this.button3_1.Size = new System.Drawing.Size(66, 53);
            this.button3_1.TabIndex = 12;
            this.button3_1.UseVisualStyleBackColor = true;
            this.button3_1.Click += new System.EventHandler(this.button3_1_Click);
            // 
            // button3_2
            // 
            this.button3_2.Location = new System.Drawing.Point(75, 121);
            this.button3_2.Name = "button3_2";
            this.button3_2.Size = new System.Drawing.Size(66, 53);
            this.button3_2.TabIndex = 13;
            this.button3_2.UseVisualStyleBackColor = true;
            this.button3_2.Click += new System.EventHandler(this.button3_2_Click);
            // 
            // button3_3
            // 
            this.button3_3.Location = new System.Drawing.Point(147, 121);
            this.button3_3.Name = "button3_3";
            this.button3_3.Size = new System.Drawing.Size(66, 53);
            this.button3_3.TabIndex = 14;
            this.button3_3.UseVisualStyleBackColor = true;
            this.button3_3.Click += new System.EventHandler(this.button3_3_Click);
            // 
            // button3_4
            // 
            this.button3_4.Location = new System.Drawing.Point(219, 121);
            this.button3_4.Name = "button3_4";
            this.button3_4.Size = new System.Drawing.Size(66, 53);
            this.button3_4.TabIndex = 15;
            this.button3_4.UseVisualStyleBackColor = true;
            this.button3_4.Click += new System.EventHandler(this.button3_4_Click);
            // 
            // button3_5
            // 
            this.button3_5.Location = new System.Drawing.Point(291, 121);
            this.button3_5.Name = "button3_5";
            this.button3_5.Size = new System.Drawing.Size(70, 53);
            this.button3_5.TabIndex = 16;
            this.button3_5.UseVisualStyleBackColor = true;
            this.button3_5.Click += new System.EventHandler(this.button3_5_Click);
            // 
            // button4_1
            // 
            this.button4_1.Location = new System.Drawing.Point(3, 180);
            this.button4_1.Name = "button4_1";
            this.button4_1.Size = new System.Drawing.Size(66, 53);
            this.button4_1.TabIndex = 17;
            this.button4_1.UseVisualStyleBackColor = true;
            this.button4_1.Click += new System.EventHandler(this.button4_1_Click);
            // 
            // button4_2
            // 
            this.button4_2.Location = new System.Drawing.Point(75, 180);
            this.button4_2.Name = "button4_2";
            this.button4_2.Size = new System.Drawing.Size(66, 53);
            this.button4_2.TabIndex = 18;
            this.button4_2.UseVisualStyleBackColor = true;
            this.button4_2.Click += new System.EventHandler(this.button4_2_Click);
            // 
            // button4_3
            // 
            this.button4_3.Location = new System.Drawing.Point(147, 180);
            this.button4_3.Name = "button4_3";
            this.button4_3.Size = new System.Drawing.Size(66, 53);
            this.button4_3.TabIndex = 19;
            this.button4_3.UseVisualStyleBackColor = true;
            this.button4_3.Click += new System.EventHandler(this.button4_3_Click);
            // 
            // button4_4
            // 
            this.button4_4.Location = new System.Drawing.Point(219, 180);
            this.button4_4.Name = "button4_4";
            this.button4_4.Size = new System.Drawing.Size(66, 53);
            this.button4_4.TabIndex = 20;
            this.button4_4.UseVisualStyleBackColor = true;
            this.button4_4.Click += new System.EventHandler(this.button4_4_Click);
            // 
            // button4_5
            // 
            this.button4_5.Location = new System.Drawing.Point(291, 180);
            this.button4_5.Name = "button4_5";
            this.button4_5.Size = new System.Drawing.Size(70, 53);
            this.button4_5.TabIndex = 21;
            this.button4_5.UseVisualStyleBackColor = true;
            this.button4_5.Click += new System.EventHandler(this.button4_5_Click);
            // 
            // button5_1
            // 
            this.button5_1.Location = new System.Drawing.Point(3, 239);
            this.button5_1.Name = "button5_1";
            this.button5_1.Size = new System.Drawing.Size(66, 55);
            this.button5_1.TabIndex = 22;
            this.button5_1.UseVisualStyleBackColor = true;
            this.button5_1.Click += new System.EventHandler(this.button5_1_Click);
            // 
            // button5_2
            // 
            this.button5_2.Location = new System.Drawing.Point(75, 239);
            this.button5_2.Name = "button5_2";
            this.button5_2.Size = new System.Drawing.Size(66, 55);
            this.button5_2.TabIndex = 23;
            this.button5_2.UseVisualStyleBackColor = true;
            this.button5_2.Click += new System.EventHandler(this.button5_2_Click);
            // 
            // button5_3
            // 
            this.button5_3.Location = new System.Drawing.Point(147, 239);
            this.button5_3.Name = "button5_3";
            this.button5_3.Size = new System.Drawing.Size(66, 55);
            this.button5_3.TabIndex = 24;
            this.button5_3.UseVisualStyleBackColor = true;
            this.button5_3.Click += new System.EventHandler(this.button5_3_Click);
            // 
            // button5_4
            // 
            this.button5_4.Location = new System.Drawing.Point(219, 239);
            this.button5_4.Name = "button5_4";
            this.button5_4.Size = new System.Drawing.Size(66, 55);
            this.button5_4.TabIndex = 25;
            this.button5_4.UseVisualStyleBackColor = true;
            this.button5_4.Click += new System.EventHandler(this.button5_4_Click);
            // 
            // button5_5
            // 
            this.button5_5.Location = new System.Drawing.Point(291, 239);
            this.button5_5.Name = "button5_5";
            this.button5_5.Size = new System.Drawing.Size(70, 55);
            this.button5_5.TabIndex = 26;
            this.button5_5.UseVisualStyleBackColor = true;
            this.button5_5.Click += new System.EventHandler(this.button5_5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1306, 599);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button1_1;
        private System.Windows.Forms.Button button1_2;
        private System.Windows.Forms.Button button1_3;
        private System.Windows.Forms.Button button1_4;
        private System.Windows.Forms.Button button1_5;
        private System.Windows.Forms.Button button2_1;
        private System.Windows.Forms.Button button2_2;
        private System.Windows.Forms.Button button2_3;
        private System.Windows.Forms.Button button2_4;
        private System.Windows.Forms.Button button2_5;
        private System.Windows.Forms.Button button3_1;
        private System.Windows.Forms.Button button3_2;
        private System.Windows.Forms.Button button3_3;
        private System.Windows.Forms.Button button3_4;
        private System.Windows.Forms.Button button3_5;
        private System.Windows.Forms.Button button4_1;
        private System.Windows.Forms.Button button4_2;
        private System.Windows.Forms.Button button4_3;
        private System.Windows.Forms.Button button4_4;
        private System.Windows.Forms.Button button4_5;
        private System.Windows.Forms.Button button5_1;
        private System.Windows.Forms.Button button5_2;
        private System.Windows.Forms.Button button5_3;
        private System.Windows.Forms.Button button5_4;
        private System.Windows.Forms.Button button5_5;
    }
}

