﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp20
{
    public partial class Form1 : Form
    {

        private Random random = new Random();
        private int[] array = new int[52];
        private int index = 0;
        private int cur_char;
        private int count = 0;
        private const int col = 5; private const int row = 5;
        private int[,] player_matrix = new int[col,row];
        private Boolean end_game = false;


        public Form1()
        {
            InitializeComponent();

            for (int i = 0; i < 52; i++)
            {
                array[i] = 1 + i / 4;
            }
            Shuffle(array);

            next_digit();

            for (int i = 0;i < col;i++)
            {
                for (int j = 0; j < row; j++)
                {
                    player_matrix[i, j] = 0;
                }
            }

            
        }

        private void Shuffle(int[] array)
        {
            for (int i = array.Length - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);

                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        private void end()
        {
            var flag = false;

            for (int i = 0; i < col; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    if (player_matrix[i, j] == 0)
                    {
                        flag = false;
                        break;
                    }
                    else
                    {
                        flag = true;
                    }
                }
            }
            if (flag)
            {
                MessageBox.Show("Конец");
                end_game = true;
            }
        }

        private void next_digit()
        {
            cur_char = array[index];
            index++;

            textBox1.Text = cur_char.ToString();

            if (index == array.Length)
            {
                index = 0;
            }
        }

        private void print_matrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0;j < matrix.GetLength(1); j++)
                {
                    Console.WriteLine($"{matrix[i, j]}\t");
                }
                Console.WriteLine("\n");
            }    
        }
        
        private void button1_1_Click(object sender, EventArgs e)
        {
            if (button1_1.Text == "")
            {
                button1_1.Text = cur_char.ToString();
                player_matrix[0, 0] = cur_char;
                next_digit();
                end();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void button1_2_Click(object sender, EventArgs e)
        {
            if (button1_2.Text == "")
            {
                button1_2.Text = cur_char.ToString();
                player_matrix[0, 1] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void button1_3_Click(object sender, EventArgs e)
        {
            if (button1_3.Text == "")
            {
                button1_3.Text = cur_char.ToString();
                player_matrix[0, 2] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button1_4_Click(object sender, EventArgs e)
        {
            if (button1_4.Text == "")
            {
                button1_4.Text = cur_char.ToString();
                player_matrix[0, 3] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button1_5_Click(object sender, EventArgs e)
        {
            if (button1_5.Text == "")
            {
                button1_5.Text = cur_char.ToString();
                player_matrix[0, 4] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button2_1_Click(object sender, EventArgs e)
        {
            if (button2_1.Text == "")
            {
                button2_1.Text = cur_char.ToString();
                player_matrix[1, 0] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button2_2_Click(object sender, EventArgs e)
        {
            if (button2_2.Text == "")
            {
                button2_2.Text = cur_char.ToString();
                player_matrix[1, 1] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button2_3_Click(object sender, EventArgs e)
        {
            if (button2_3.Text == "")
            {
                button2_3.Text = cur_char.ToString();
                player_matrix[1, 2] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button2_4_Click(object sender, EventArgs e)
        {
            if (button2_4.Text == "")
            {
                button2_4.Text = cur_char.ToString();
                player_matrix[1, 3] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button2_5_Click(object sender, EventArgs e)
        {
            if (button2_5.Text == "")
            {
                button2_5.Text = cur_char.ToString();
                player_matrix[1, 4] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button3_1_Click(object sender, EventArgs e)
        {
            if (button3_1.Text == "")
            {
                button3_1.Text = cur_char.ToString();
                player_matrix[2, 0] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button3_2_Click(object sender, EventArgs e)
        {
            if (button3_2.Text == "")
            {
                button3_2.Text = cur_char.ToString();
                player_matrix[2, 1] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button3_3_Click(object sender, EventArgs e)
        {
            if (button3_3.Text == "")
            {
                button3_3.Text = cur_char.ToString();
                player_matrix[2, 2] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button3_4_Click(object sender, EventArgs e)
        {
            if (button3_4.Text == "")
            {
                button3_4.Text = cur_char.ToString();
                player_matrix[2, 3] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button3_5_Click(object sender, EventArgs e)
        {
            if (button3_5.Text == "")
            {
                button3_5.Text = cur_char.ToString();
                player_matrix[2, 4] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button4_1_Click(object sender, EventArgs e)
        {
            if (button4_1.Text == "")
            {
                button4_1.Text = cur_char.ToString();
                player_matrix[3, 0] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button4_2_Click(object sender, EventArgs e)
        {
            if (button4_2.Text == "")
            {
                button4_2.Text = cur_char.ToString();
                player_matrix[3, 1] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button4_3_Click(object sender, EventArgs e)
        {
            if (button4_3.Text == "")
            {
                button4_3.Text = cur_char.ToString();
                player_matrix[3, 2] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button4_4_Click(object sender, EventArgs e)
        {
            if (button4_4.Text == "")
            {
                button4_4.Text = cur_char.ToString();
                player_matrix[3, 3] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button4_5_Click(object sender, EventArgs e)
        {
            if (button4_5.Text == "")
            {
                button4_5.Text = cur_char.ToString();
                player_matrix[3, 4] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button5_1_Click(object sender, EventArgs e)
        {
            if (button5_1.Text == "")
            {
                button5_1.Text = cur_char.ToString();
                player_matrix[4, 0] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button5_2_Click(object sender, EventArgs e)
        {
            if (button5_2.Text == "")
            {
                button5_2.Text = cur_char.ToString();
                player_matrix[4, 1] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button5_3_Click(object sender, EventArgs e)
        {
            if (button5_3.Text == "")
            {
                button5_3.Text = cur_char.ToString();
                player_matrix[4, 2] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button5_4_Click(object sender, EventArgs e)
        {
            if (button5_4.Text == "")
            {
                button5_4.Text = cur_char.ToString();
                player_matrix[4, 3] = cur_char;
                end();
                next_digit();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

        }

        private void button5_5_Click(object sender, EventArgs e)
        {
            if (button5_5.Text == "")
            {
                button5_5.Text = cur_char.ToString();
                player_matrix[4, 4] = cur_char;
                count++;
                next_digit();
                end();
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }
    }
}
